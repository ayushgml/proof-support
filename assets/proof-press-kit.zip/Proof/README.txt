Proof: Daily Accountability
Goals, daily planning, focus and useful nudges for iPhone, iPad and Apple Watch.
Website: https://proof.itsayush.dev/
Support: https://proof.itsayush.dev/support
Contact: ayushgml@gmail.com
App Store release: submitted; waiting for Apple review as of 5 October 2026.
Screens show real UI with demonstration data. Schedule images show an empty example week. The background artwork was generated; the logo and screenshots are existing product assets.
Copyright 2026 Ayush Gupta. Assets may be used to accurately represent Proof in editorial coverage; no other licence is granted.
